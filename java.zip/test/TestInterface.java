package test;

public interface TestInterface 
{
	public void testExe();
}
